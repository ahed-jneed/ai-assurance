import copy
import json
import runpy
from pathlib import Path

p = Path(__file__).with_name('test-run.schema.json')
s = json.loads(p.read_text(encoding='utf-8'))
old = copy.deepcopy(s.get('$defs', {}).get('legacyRun', s))
defs = copy.deepcopy(s['$defs'])
old.pop('$defs', None)
for key in ('$schema', '$id', 'title', 'description'):
    old.pop(key, None)

def ref(name): return {'$ref': '#/$defs/' + name}
def st(minimum=0, maximum=5000): return {'type': 'string', 'minLength': minimum, 'maxLength': maximum}
def en(*values): return {'enum': list(values)}
def it(minimum=0, maximum=None):
    value = {'type': 'integer', 'minimum': minimum}
    if maximum is not None: value['maximum'] = maximum
    return value
def num(minimum=None, maximum=None):
    value = {'type': 'number'}
    if minimum is not None: value['minimum'] = minimum
    if maximum is not None: value['maximum'] = maximum
    return value
def arr(items, minimum=0, maximum=None, unique=False):
    value = {'type': 'array', 'items': items, 'minItems': minimum}
    if maximum is not None: value['maxItems'] = maximum
    if unique: value['uniqueItems'] = True
    return value
def obj(properties, required=None):
    return {'type': 'object', 'additionalProperties': False, 'properties': properties, 'required': list(properties) if required is None else required}
def nullable(value): return {'anyOf': [value, {'type': 'null'}]}
def condition(props, then): return {'if': {'properties': props, 'required': list(props)}, 'then': then}

date = {'type': 'string', 'format': 'date-time'}
ratio = num(0, 1)
version = {**st(1, 100), 'pattern': r'^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$'}
defs['actorId'] = st(1, 300)
defs['semanticVersion'] = version
defs['stringNotes'] = arr(st(1, 10000), 0, 1000)
defs['testDefinitionVersions'] = {'type': 'object', 'minProperties': 1, 'propertyNames': st(1, 300), 'additionalProperties': ref('semanticVersion')}
defs['datasetInput'] = obj({'name': st(1, 5000), 'sha256': ref('sha256'), 'bytes': it(0, 104857600), 'rowCount': it(1, 1000000), 'columns': arr(st(1, 5000), 1, 1000, True), 'format': {'const': 'parquet'}, 'decodedBytes': it(0, 104857600), 'connectorVersion': ref('semanticVersion')}, ['name', 'sha256', 'bytes', 'rowCount', 'columns'])
defs['datasetInput']['allOf'] = [condition({'format': {'const': 'parquet'}}, {'required': ['decodedBytes', 'connectorVersion']})]
sqlIdentifier = {**st(1, 128), 'pattern': r'^[A-Za-z_][A-Za-z0-9_]{0,127}$'}
defs['sqliteSpecification'] = obj({'table': sqlIdentifier, 'columns': arr(sqlIdentifier, 1, 1000, True), 'orderBy': sqlIdentifier, 'boundColumn': sqlIdentifier, 'lower': num(), 'upper': num(), 'limit': it(1, 1000000)}, ['table', 'columns', 'orderBy'])
defs['sqliteSpecification']['allOf'] = [{'if': {'anyOf': [{'required': ['lower']}, {'required': ['upper']}]}, 'then': {'required': ['boundColumn']}}]
defs['sqliteInput'] = obj({'schemaVersion': {'const': '1.0'}, 'connectorVersion': ref('semanticVersion'), 'sourceName': st(1, 5000), 'sourceKind': {'const': 'sqlite_read_only'}, 'snapshotSha256': ref('sha256'), 'specification': ref('sqliteSpecification'), 'specificationSha256': ref('sha256'), 'rowCount': it(1, 1000000), 'bytes': it(0, 104857600), 'isolation': {'const': 'SQLite read transaction; mode=ro; query_only; no user SQL'}})
defs['modelInput'] = obj({'sha256': ref('sha256'), 'format': en('onnx', 'pmml', 'xgboost_json', 'lightgbm_text'), 'featureColumns': arr(st(1, 5000), 1, 100, True)})
defs['pythonInputs'] = obj({'data': ref('datasetInput'), 'reference': nullable(ref('datasetInput')), 'model': ref('modelInput'), 'testDefinitions': ref('testDefinitionVersions'), 'sourceSnapshot': ref('sqliteInput')}, ['data'])
defs['runtimeDependencies'] = obj({'python': obj({'version': ref('semanticVersion'), 'implementation': st(1, 100)}), 'packages': {'type': 'object', 'propertyNames': {**st(1, 300), 'pattern': r'^[A-Za-z0-9][A-Za-z0-9._-]*$'}, 'additionalProperties': nullable(st(1, 300))}, 'adapterDeclaration': en('not_used', 'missing', 'provided'), 'unresolved': arr(st(1, 300), 0, 1000, True), 'status': en('complete', 'partial'), 'standardLibraryOnly': {'type': ['boolean', 'null']}, 'source': st(1, 5000), 'scope': st(1, 5000)})
defs['legacyDependencies'] = obj({'python': st(1, 100)})
legacyProvenance = old['properties']['provenance']['properties']
legacyProvenance['inputs'] = ref('pythonInputs')
legacyProvenance['dependencies'] = {'oneOf': [ref('runtimeDependencies'), ref('legacyDependencies')]}
legacyProvenance['runtime'] = ref('runtimeDependencies')
legacyProvenance['testDefinitionVersions'] = ref('testDefinitionVersions')
pythonTask = en('binary_classification', 'multiclass_classification', 'regression')
defs['pythonModelSpec'] = obj({'task': pythonTask, 'featureColumns': arr(st(1, 5000), 1, 100, True), 'outputLabels': arr(st(0, 5000), 0, 1000, True), 'decisionThreshold': ratio, 'predictionOutput': st(1, 5000), 'probabilityOutput': st(1, 5000)}, ['task', 'featureColumns'])
defs['pythonModelSpec']['allOf'] = [condition({'task': en('binary_classification', 'multiclass_classification')}, {'required': ['outputLabels'], 'properties': {'outputLabels': {'minItems': 2}}}), condition({'task': {'const': 'binary_classification'}}, {'properties': {'outputLabels': {'maxItems': 2}}})]
defs['pythonModelSpec']['properties'].update(predictionKind=en('label', 'probability'), labelEncoding=en('label', 'class_index'))
defs['pythonConfig'] = obj({'contractVersion': {'const': '1.0'}, 'id': ref('id'), 'engagementId': ref('id'), 'modelId': ref('id'), 'datasetId': ref('id'), 'task': pythonTask, 'suite': arr(en('performance', 'fairness', 'drift', 'shap', 'lime', 'permutation_importance', 'cross_validation', 'perturbation', 'adversarial', 'inference', 'record_keeping'), 1, 11, True), 'thresholds': ref('engineThresholds'), 'seed': it(0, 4294967295), 'columns': obj({x: st(1, 5000) for x in ('target', 'prediction', 'score', 'protected')}, []), 'positiveLabel': st(1, 5000), 'negativeLabel': st(1, 5000), 'minGroupSize': it(2, 1000000), 'minClassCount': it(2, 1000000), 'minSampleSize': it(2, 1000000), 'psiBins': it(2, 100), 'calibrationBins': it(2, 100), 'driftFeatures': arr(st(1, 5000), 1, 1000, True), 'modelSpec': ref('pythonModelSpec'), 'permutation': obj({'repeats': it(2, 20)}, []), 'perturbation': obj({'approvalId': st(1, 5000), 'rationale': st(1, 10000), 'features': {'type': 'object', 'minProperties': 1, 'propertyNames': st(1, 5000), 'additionalProperties': obj({'lower': num(), 'upper': num(), 'delta': {'type': 'number', 'exclusiveMinimum': 0}})}})}, ['contractVersion', 'id', 'engagementId', 'modelId', 'datasetId', 'task', 'suite', 'thresholds', 'seed', 'minGroupSize', 'minClassCount', 'minSampleSize', 'psiBins', 'calibrationBins'])
defs['pythonConfig']['allOf'] = [condition({'suite': {'contains': en('performance', 'fairness')}}, {'required': ['columns'], 'properties': {'columns': {'required': ['target', 'prediction']}}}), condition({'suite': {'contains': {'const': 'drift'}}}, {'required': ['driftFeatures']}), condition({'task': {'const': 'binary_classification'}}, {'required': ['positiveLabel', 'negativeLabel']})]
old['properties']['configuration'] = ref('pythonConfig')
configProps = {'labelColumn': st(1, 300), 'predictionColumn': st(1, 300), 'groupColumn': st(0, 300), 'positiveLabel': st(0, 300), 'minimumGroupSize': it(2, 1000), 'maximumParityGap': ratio, 'minimumImpactRatio': ratio, 'minimumAccuracy': ratio, 'minimumSampleSize': it(2, 10000), 'minimumClassCount': it(1, 1000), 'maximumOddsGap': ratio, 'minimumRecall': ratio, 'minimumMacroF1': ratio, 'maximumRmse': {'type': 'number', 'exclusiveMinimum': 0, 'maximum': 1e100}}
defs['hostedConfig'] = obj(configProps)
defs['hostedTranslation'] = obj({'version': st(1, 300), 'sourceContract': {'const': '1.1'}, 'selectedTests': arr(en('performance', 'regression', 'demographic_parity', 'disparate_impact', 'equalized_odds', 'drift', 'permutation', 'perturbation', 'explainability', 'cross_validation'), 1, 10, True), 'sourceConfiguration': ref('hostedConfig'), 'minimumClassCount': it(1, 1000), 'supplementalMetricPolicy': st(1, 5000)})
defs['pythonConfig']['properties']['hostedTranslation'] = ref('hostedTranslation')
legacyConfigProps = copy.deepcopy(configProps)
legacyConfigProps['minimumGroupSize'] = it(1, 1000)
defs['legacyInteractiveConfig'] = obj(legacyConfigProps, list(configProps)[:8])
old['properties']['config'] = ref('legacyInteractiveConfig')
legacyThresholds = defs['interactiveThresholds']
legacyThresholds['additionalProperties'] = False
legacyThresholds['properties'].update(copy.deepcopy(legacyConfigProps))
legacyThresholds['properties']['frozenBy'] = ref('actorId')
defs['legacyRun'] = old
hostedTasks = en('Binary classification', 'Multiclass classification', 'Regression')
allTasks = en('Binary classification', 'Multiclass classification', 'Regression', 'Classical NLP')
hostedSuite = arr(en('performance', 'regression', 'demographic_parity', 'disparate_impact', 'equalized_odds'), 1, 5, True)
def taskSuiteRules():
    return [condition({'task': {'const': 'Binary classification'}}, {'properties': {'suite': {'items': en('performance', 'demographic_parity', 'disparate_impact', 'equalized_odds')}, 'config': {'properties': {'positiveLabel': {'minLength': 1}}}}}), condition({'task': {'const': 'Multiclass classification'}}, {'properties': {'suite': {'items': {'const': 'performance'}}}}), condition({'task': {'const': 'Regression'}}, {'properties': {'suite': {'items': {'const': 'regression'}}}}), condition({'suite': {'contains': en('demographic_parity', 'disparate_impact', 'equalized_odds')}}, {'properties': {'config': {'properties': {'groupColumn': {'minLength': 1}, 'positiveLabel': {'minLength': 1}}}}})]
defs['modelCardSource'] = obj({'kind': en('internal', 'huggingface'), 'repoId': st(0, 5000), 'revision': st(0, 5000), 'filename': st(0, 5000)})
defs['modelCardSource']['allOf'] = [condition({'kind': {'const': 'huggingface'}}, {'properties': {'repoId': {'pattern': r'^[\w.-]+/[\w.-]+$'}, 'revision': {'pattern': r'^[a-fA-F0-9]{40}$'}, 'filename': {'minLength': 1, 'pattern': r'^(?!/)(?!.*(?:^|/)\.\.(?:/|$))[^\\]+$'}}})]
defs['modelCard'] = obj({'schemaVersion': {'const': '1.0'}, 'owner': st(1, 300), 'framework': st(1, 300), 'license': st(0, 5000), 'population': st(0, 5000), 'outOfScope': st(0, 5000), 'limitations': st(0, 5000), 'inputSchema': st(0, 5000), 'outputSemantics': st(1, 300), 'preprocessing': st(0, 5000), 'source': ref('modelCardSource')})
defs['registeredModel'] = obj({'id': ref('id'), 'name': st(1, 300), 'version': st(1, 300), 'format': st(1, 300), 'task': allTasks, 'intendedPurpose': st(1, 5000), 'artifactId': ref('id'), 'status': en('registered', 'quarantined'), 'familyId': ref('id'), 'card': ref('modelCard'), 'sourceSha256': ref('sha256'), 'registeredAt': date, 'registeredBy': ref('actorId')}, ['id', 'name', 'version', 'format', 'task', 'intendedPurpose', 'artifactId', 'status'])
defs['predictionDataset'] = obj({'id': ref('id'), 'name': st(1, 5000), 'sha256': ref('sha256'), 'size': it(1, 1048576), 'rowCount': it(1, 10000), 'columns': arr(st(1, 300), 1, 200, True)})
defs['datasetContext'] = obj({'split': en('test', 'validation', 'training', 'unknown'), 'population': st(1, 5000), 'predictionProvenance': st(1, 5000), 'independence': st(1, 5000), 'sensitiveDataBasis': st(0, 5000)})
defs['evaluationProfile'] = obj({'id': ref('id'), 'schemaVersion': {'const': '1.0'}, 'name': st(1, 300), 'version': st(1, 300), 'task': hostedTasks, 'suite': hostedSuite, 'config': ref('hostedConfig'), 'datasetContext': ref('datasetContext'), 'rationale': st(1, 5000), 'createdAt': date, 'createdBy': ref('actorId')})
defs['evaluationProfile']['allOf'] = taskSuiteRules()
defs['runManifest'] = obj({'schemaVersion': {'const': '1.0'}, 'model': ref('registeredModel'), 'dataset': ref('predictionDataset'), 'profile': nullable(ref('evaluationProfile')), 'executionMode': {'const': 'saved_predictions'}, 'lineage': {'const': 'registered_prediction_artifact'}, 'testDefinitionVersion': {**st(1, 100), 'pattern': r'^traditional-ml-\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$'}, 'limitations': ref('stringNotes')})
defs['runManifest']['properties']['model'] = {'allOf': [ref('registeredModel'), {'properties': {'format': {'const': 'Prediction file'}, 'status': {'const': 'registered'}, 'task': hostedTasks}}]}
defs['hostedThresholds'] = obj({'source': {'const': 'internal_policy'}, 'policyId': st(1, 300), 'policyVersion': st(1, 300), 'frozenAt': date, 'frozenBy': ref('actorId'), **copy.deepcopy(configProps)})
defs['hostedInputHashes'] = obj({k: ref('sha256') for k in ('dataset', 'modelMetadata', 'modelArtifact', 'protocol', 'manifest', 'configuration', 'auditBinding')}, ['dataset', 'modelMetadata', 'modelArtifact', 'manifest', 'configuration'])
defs['hostedProvenance'] = obj({'inputHashes': ref('hostedInputHashes'), 'runnerVersion': {**st(1, 100), 'pattern': r'^interactive-predictions-\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$'}, 'policyVersion': st(1, 300)})
confusionProps = {**{k: it(0, 10000) for k in ('tp', 'tn', 'fp', 'fn', 'n')}, 'rate': ratio, 'tpr': nullable(ratio), 'fpr': nullable(ratio)}
defs['confusionMatrix'] = obj(confusionProps)
defs['fairnessGroup'] = obj({'group': st(1, 5000), **copy.deepcopy(confusionProps)})
defs['classPerformance'] = obj({'label': st(1, 5000), 'support': it(0, 10000), 'predicted': it(0, 10000), 'tp': it(0, 10000), 'recall': nullable(ratio), 'precision': nullable(ratio), 'f1': nullable(ratio)})
defs['hostedMetric'] = obj({'name': en('accuracy', 'precision', 'recall', 'f1', 'macro_f1', 'balanced_accuracy', 'mae', 'rmse', 'r2', 'maximum_selection_rate_gap', 'minimum_selection_rate_ratio', 'maximum_tpr_fpr_gap'), 'value': nullable(num()), 'unit': en('ratio', 'target units', 'score'), 'sampleSize': it(0, 10000), 'details': {'oneOf': [ref('confusionMatrix'), arr(ref('fairnessGroup'), 1, 10000), arr(ref('classPerformance'), 1, 10000)]}}, ['name', 'value', 'unit', 'sampleSize'])
defs['hostedMetric']['allOf'] = [condition({'name': en('accuracy', 'precision', 'recall', 'f1', 'macro_f1', 'balanced_accuracy', 'maximum_selection_rate_gap', 'minimum_selection_rate_ratio', 'maximum_tpr_fpr_gap')}, {'properties': {'unit': {'const': 'ratio'}, 'value': nullable(ratio)}}), condition({'name': en('mae', 'rmse')}, {'properties': {'unit': {'const': 'target units'}, 'value': nullable(num(0))}}), condition({'name': {'const': 'r2'}}, {'properties': {'unit': {'const': 'score'}, 'value': nullable(num(None, 1))}})]
defs['hostedResult'] = obj({'testId': en('performance', 'regression', 'demographic_parity', 'disparate_impact', 'equalized_odds'), 'label': st(1, 300), 'article': en('10', '15'), 'outcome': en('pass', 'fail', 'inconclusive', 'not_applicable'), 'metrics': arr(ref('hostedMetric'), 0, 20), 'limitations': ref('stringNotes')})
resultRules = [condition({'outcome': en('pass', 'fail')}, {'properties': {'metrics': {'minItems': 1}}}), condition({'outcome': en('inconclusive', 'not_applicable')}, {'properties': {'limitations': {'minItems': 1}}})]
for test, names, article in [('performance', ['accuracy', 'precision', 'recall', 'f1', 'macro_f1', 'balanced_accuracy'], '15'), ('regression', ['mae', 'rmse', 'r2'], '15'), ('demographic_parity', ['maximum_selection_rate_gap'], '10'), ('disparate_impact', ['minimum_selection_rate_ratio'], '10'), ('equalized_odds', ['maximum_tpr_fpr_gap'], '10')]:
    resultRules.append(condition({'testId': {'const': test}}, {'properties': {'article': {'const': article}, 'metrics': {'items': {'properties': {'name': en(*names)}}}}}))
defs['hostedResult']['allOf'] = resultRules
run = obj({'contractVersion': {'const': '1.1'}, 'id': ref('id'), 'engagementId': ref('id'), 'modelId': ref('id'), 'datasetId': ref('id'), 'suite': hostedSuite, 'seed': it(0, 4294967295), 'thresholds': ref('hostedThresholds'), 'state': en('queued', 'running', 'succeeded', 'failed', 'cancelled'), 'outcome': en(None, 'pass', 'fail', 'inconclusive', 'not_applicable'), 'overallOutcome': en('pass', 'fail', 'inconclusive', 'not_applicable'), 'results': arr(ref('hostedResult'), 0, 5), 'paperIds': arr(ref('id'), 0, 5, True), 'createdAt': date, 'startedAt': date, 'completedAt': date, 'error': st(1, 10000), 'provenance': ref('hostedProvenance'), 'config': ref('hostedConfig'), 'task': hostedTasks, 'profileId': ref('id'), 'manifest': ref('runManifest')}, ['contractVersion', 'id', 'engagementId', 'modelId', 'datasetId', 'suite', 'seed', 'thresholds', 'state', 'outcome', 'results', 'paperIds', 'createdAt', 'provenance', 'config', 'task', 'manifest'])
run['description'] = 'Hosted v1.1 saved-prediction execution with frozen model/card, dataset, protocol and configuration snapshots. SHA-256 values describe content; authenticity and cross-field equality require the application validator.'
profileIf = {'properties': {'manifest': {'properties': {'profile': {'type': 'object'}}, 'required': ['profile']}}, 'required': ['manifest']}
profileThen = {'required': ['profileId'], 'properties': {'provenance': {'properties': {'inputHashes': {'required': ['protocol']}}}}}
profileElse = {'not': {'required': ['profileId']}, 'properties': {'provenance': {'properties': {'inputHashes': {'not': {'required': ['protocol']}}}}}}
run['allOf'] = taskSuiteRules() + [
    condition({'state': {'const': 'queued'}}, {'properties': {'outcome': {'type': 'null'}, 'results': {'maxItems': 0}, 'paperIds': {'maxItems': 0}}, 'not': {'anyOf': [{'required': ['startedAt']}, {'required': ['completedAt']}, {'required': ['overallOutcome']}, {'required': ['error']}]}}),
    condition({'state': {'const': 'running'}}, {'required': ['startedAt'], 'properties': {'outcome': {'type': 'null'}, 'results': {'maxItems': 0}, 'paperIds': {'maxItems': 0}}, 'not': {'anyOf': [{'required': ['completedAt']}, {'required': ['overallOutcome']}, {'required': ['error']}]}}),
    condition({'state': {'const': 'succeeded'}}, {'required': ['startedAt', 'completedAt', 'overallOutcome'], 'properties': {'outcome': en('pass', 'fail', 'inconclusive', 'not_applicable'), 'results': {'minItems': 1}, 'paperIds': {'minItems': 1}}, 'not': {'required': ['error']}}),
    condition({'state': en('failed', 'cancelled')}, {'required': ['completedAt', 'overallOutcome'], 'properties': {'outcome': {'const': 'inconclusive'}, 'overallOutcome': {'const': 'inconclusive'}}}),
    condition({'state': {'const': 'failed'}}, {'required': ['error']}),
    {'if': profileIf, 'then': profileThen, 'else': profileElse},
]
for outcome in ('pass', 'fail', 'inconclusive', 'not_applicable'):
    run['allOf'].append(condition({'outcome': {'const': outcome}}, {'properties': {'overallOutcome': {'const': outcome}}}))
for task, tests in [('Binary classification', ['performance', 'demographic_parity', 'disparate_impact', 'equalized_odds']), ('Multiclass classification', ['performance']), ('Regression', ['regression'])]:
    manifestTask = {'properties': {'model': {'properties': {'task': {'const': task}}}, 'profile': {'anyOf': [{'type': 'null'}, {'properties': {'task': {'const': task}}}]}}}
    resultTests = {'items': {'properties': {'testId': en(*tests)}}}
    run['allOf'].append(condition({'task': {'const': task}}, {'properties': {'manifest': manifestTask, 'results': resultTests}}))
defs['procedureBinding'] = obj({'procedureId': ref('id'), 'procedureRevision': it(1, 2147483647), 'briefRevision': it(1, 2147483647), 'programRevision': it(1, 2147483647)})
run['properties']['procedureBinding'] = ref('procedureBinding')
run['properties']['retryOf'] = ref('id')
run['allOf'].append({'if': {'required': ['procedureBinding']}, 'then': {'properties': {'provenance': {'properties': {'inputHashes': {'required': ['auditBinding']}}}}}, 'else': {'properties': {'provenance': {'properties': {'inputHashes': {'not': {'required': ['auditBinding']}}}}}}})
defs['hostedRun'] = run
output = {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:ai-assurance:test-run:1.1', 'title': 'AI Assurance common diagnostic run contract', 'description': 'Version-discriminated contract: v1.0 Python/legacy interactive runs and v1.1 hosted saved-prediction runs. Frozen internal policies and diagnostic outcomes provide audit evidence; they do not certify EU AI Act conformity. Application validation must verify hashes, cross-field bindings, timestamp order and evidence custody.', 'oneOf': [ref('legacyRun'), ref('hostedRun')], '$defs': defs}
extend = runpy.run_path(str(Path(__file__).with_name('.extend-assurance-schema.py')))['extend_schema']
output = extend(output)
p.write_text(json.dumps(output, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print('Updated schema with', len(defs), 'definitions')
