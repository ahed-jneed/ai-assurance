"""Auditable traditional-ML diagnostics. No pickle/joblib or user-code loading."""

__version__ = "1.5.0"
