"""Pull worker for /api/runner; no submitted code or dynamic package installs.

Default execution is provided predictions in a bounded child process. Native
inference requires an explicitly selected, digest-pinned Docker executor with
network disabled and a local artifact SHA-256 allowlist.
"""
from __future__ import annotations

import argparse
import importlib
import importlib.metadata
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .contract import validate_report
from .diagnostics import MAX_BYTES, read_csv, run, sha256
from .worker_contract import Claim, FORMAT_ALIASES, MAX_ENVELOPE_BYTES, MAX_RESULT_BYTES, WORKER_VERSION, completion_body, evidence_envelope, json_bytes, result_signature, strict_json, timestamp, translate_config, valid_hash, valid_id

MODEL_SUFFIXES = {"onnx": ".onnx", "pmml": ".pmml", "xgboost_json": ".json", "lightgbm_text": ".txt"}
RUNTIME_PACKAGES = {"onnx": ("numpy", "onnxruntime"), "pmml": ("numpy", "pandas", "pypmml"), "xgboost_json": ("numpy", "xgboost"), "lightgbm_text": ("numpy", "lightgbm")}
WIRE_FORMATS = {"onnx": "ONNX", "pmml": "PMML", "xgboost_json": "XGBoost", "lightgbm_text": "LightGBM"}
MODULES = {"onnxruntime": "onnxruntime", "pypmml": "pypmml"}
IMAGE_DIGEST = re.compile(r"^sha256:[a-f0-9]{64}$")


class ProtocolError(Exception):
    """Sanitized transport failure; never contains tokens or response bodies."""
    def __init__(self, code, *, retryable=False, status=None):
        super().__init__(code)
        self.code, self.retryable, self.status = code, retryable, status


class LeaseLost(ProtocolError):
    pass


class CompletionUncertain(ProtocolError):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # A service redirect must never forward worker credentials.
        return None


class Transport:
    def __init__(self, site, application_token, platform_token=None, *, timeout=15, retries=2, allow_local_http=False):
        parsed = urllib.parse.urlsplit(site)
        local = parsed.hostname in {"localhost", "127.0.0.1", "::1"}
        if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {"", "/"} or not parsed.hostname:
            raise ValueError("Site must be an HTTPS origin without credentials/path/query")
        if parsed.scheme != "https" and not (allow_local_http and local and parsed.scheme == "http"):
            raise ValueError("Worker transport requires HTTPS; local HTTP is test-only")
        if not application_token or any(c in application_token for c in "\r\n") or platform_token and any(c in platform_token for c in "\r\n"):
            raise ValueError("Invalid worker credential configuration")
        if not 1 <= timeout <= 60 or not 0 <= retries <= 3:
            raise ValueError("Transport timeout/retry bounds exceeded")
        self.endpoint = site.rstrip("/")+"/api/runner"
        self.application_token, self.platform_token = application_token, platform_token
        self.timeout, self.retries = timeout, retries
        self.opener = urllib.request.build_opener(NoRedirect())

    def _request(self, method, url, *, body=None, maximum=MAX_ENVELOPE_BYTES, retry=False, sign=False, check_active=None):
        headers = {"Authorization": "Bearer "+self.application_token, "Accept": "application/json", "User-Agent": "ai-assurance-worker/"+WORKER_VERSION}
        if self.platform_token:
            headers["OAI-Sites-Authorization"] = "Bearer "+self.platform_token
        if body is not None:
            headers["Content-Type"] = "application/json; charset=utf-8"
        if sign:
            headers["X-Result-Signature"] = result_signature(self.application_token, body)
        deadline = time.monotonic()+self.timeout
        for attempt in range((self.retries if retry else 0)+1):
            try:
                if check_active:
                    check_active()
                remaining = deadline-time.monotonic()
                if remaining <= 0:
                    raise ProtocolError("response_deadline_exceeded", retryable=True)
                with self.opener.open(urllib.request.Request(url, data=body, method=method, headers=headers), timeout=remaining) as response:
                    declared = response.headers.get("Content-Length")
                    if declared and (not declared.isdigit() or int(declared) > maximum):
                        raise ProtocolError("response_size_rejected")
                    # HTTPResponse.read1 performs at most one raw read. read(n)
                    # can instead wait for n slowly trickling bytes indefinitely.
                    reader = getattr(response, "read1", response.read)
                    chunks, size = [], 0
                    while True:
                        if check_active:
                            check_active()
                        if time.monotonic() >= deadline:
                            raise ProtocolError("response_deadline_exceeded", retryable=True)
                        chunk = reader(min(65536, maximum+1-size))
                        if check_active:
                            check_active()
                        if time.monotonic() >= deadline:
                            raise ProtocolError("response_deadline_exceeded", retryable=True)
                        if not chunk:
                            return b"".join(chunks)
                        size += len(chunk)
                        if size > maximum:
                            raise ProtocolError("response_size_rejected")
                        chunks.append(chunk)
            except urllib.error.HTTPError as exc:
                error = ProtocolError("http_"+str(exc.code), retryable=exc.code in {429, 502, 503, 504}, status=exc.code)
                exc.close()
            except (urllib.error.URLError, TimeoutError, OSError):
                error = ProtocolError("transport_unavailable", retryable=True)
            if not retry or not error.retryable or attempt >= self.retries:
                raise error
            time.sleep(min(2, .25 * 2**attempt))
        raise ProtocolError("transport_unavailable")

    def post(self, body, *, retry=False):
        payload = body if isinstance(body, bytes) else json_bytes(body)
        raw = self._request("POST", self.endpoint, body=payload, retry=retry, sign=True)
        return strict_json(raw) if raw else None

    def input(self, claim, purpose, *, maximum, check_active=None):
        if purpose not in {"dataset", "model"}:
            raise ValueError("Unsupported input purpose")
        query = urllib.parse.urlencode({"jobId": claim.job_id, "attemptId": claim.attempt_id, "fence": claim.fence, "input": purpose})
        return self._request("GET", self.endpoint+"?"+query, maximum=maximum, retry=True, check_active=check_active)


class LeaseKeeper:
    def __init__(self, transport, claim, *, interval=10):
        self.transport, self.claim = transport, claim
        self.interval = max(.05, interval)
        self.until = timestamp(claim.lease_until)
        self.stop = threading.Event()
        self.lost = threading.Event()
        self.thread = threading.Thread(target=self._loop, name="worker-lease", daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def valid(self):
        if self.lost.is_set() or datetime.now(timezone.utc) >= self.until:
            self.lost.set()
            raise LeaseLost("lease_lost")

    def _loop(self):
        while not self.stop.is_set():
            remaining = (self.until-datetime.now(timezone.utc)).total_seconds()
            if remaining <= 0:
                self.lost.set()
                return
            if self.stop.wait(min(self.interval, max(.05, remaining/3))):
                return
            try:
                response = self.transport.post({"op": "heartbeat", **self.claim.pins()}, retry=True)
                if not isinstance(response, dict):
                    raise ProtocolError("invalid_heartbeat_response")
                updated = timestamp(response.get("leaseUntil"))
                if updated <= datetime.now(timezone.utc):
                    raise ProtocolError("heartbeat_lease_expired")
                self.until = updated
            except ProtocolError as error:
                # A temporary failure can consume the remaining lease; stale
                # workers never publish after authoritative expiry/rejection.
                if not error.retryable or datetime.now(timezone.utc) >= self.until:
                    self.lost.set()
                    return
            except (ValueError, TypeError):
                self.lost.set()
                return

    def __exit__(self, *_):
        self.stop.set()
        self.thread.join(timeout=60)


def runtime_readiness():
    formats = {}
    for format_name, names in RUNTIME_PACKAGES.items():
        packages, errors = {}, []
        for name in names:
            try:
                packages[name] = importlib.metadata.version(name)
                importlib.import_module(MODULES.get(name, name))
            except (ImportError, OSError, importlib.metadata.PackageNotFoundError):
                packages[name] = None
                errors.append("runtime_unavailable:"+name)
        if format_name == "pmml" and not shutil.which("java"):
            errors.append("runtime_unavailable:java")
        formats[format_name] = {"runtimePresent": not errors, "packages": packages, "limitations": errors or ["Runtime import availability does not validate native inference or model safety; golden model fixtures are required before enrollment."]}
    return {"schemaVersion": "1.0", "workerVersion": WORKER_VERSION, "provided_predictions": {"runtimePresent": True, "packages": {}}, "modelFormats": formats}


def stripped_compute_env():
    # No service tokens, proxy credentials or user package paths in compute.
    keep = {name: os.environ[name] for name in ("PATH", "SystemRoot", "WINDIR", "TEMP", "TMP", "LANG", "LC_ALL") if name in os.environ}
    keep.update(PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    return keep


def docker_control_env():
    # Operator-selected local/rootless Docker connection belongs to the
    # launcher, not inference. These values never enter `docker run -e`.
    result = stripped_compute_env()
    for name in ("DOCKER_HOST", "DOCKER_CONTEXT", "XDG_RUNTIME_DIR"):
        if name in os.environ:
            result[name] = os.environ[name]
    return result


class ProcessExecutor:
    network_isolation = "local_process_only"
    permits_models = False

    def readiness(self):
        return runtime_readiness()

    def command(self, inputs, outputs):
        return [sys.executable, "-I", "-c", "import sys;sys.path.insert(0,sys.argv.pop(1));from engine.worker import compute_main;sys.exit(compute_main(sys.argv[1],sys.argv[2]))", str(Path(__file__).resolve().parent.parent), str(inputs), str(outputs)]

    def environment(self):
        return stripped_compute_env()

    def execute(self, inputs, outputs, lease, timeout):
        self._execute_command(self.command(inputs, outputs), inputs, outputs, lease, timeout)

    def _execute_command(self, command, inputs, outputs, lease, timeout):
        process = subprocess.Popen(command, cwd=Path(__file__).resolve().parent.parent, env=self.environment(), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        started = time.monotonic()
        try:
            while process.poll() is None:
                lease.valid()
                if time.monotonic()-started > timeout:
                    raise ProtocolError("compute_timeout")
                time.sleep(.05)
            lease.valid()
            if process.returncode != 0:
                raise ProtocolError("compute_rejected")
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=10)


class DockerExecutor(ProcessExecutor):
    network_isolation = "docker_network_none"
    permits_models = True

    def environment(self):
        return docker_control_env()

    def __init__(self, image, *, memory="1g", cpus="1", pids=64):
        # Digest only: mutable tags cannot establish enrolled runtime identity.
        if not isinstance(image, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9./:_-]*@sha256:[a-f0-9]{64}", image):
            raise ValueError("Docker computation requires a repository@sha256 digest")
        if not re.fullmatch(r"[1-9][0-9]{0,4}[mg]", memory) or not re.fullmatch(r"[1-9][0-9]?(?:\.[0-9]{1,2})?", cpus) or not 16 <= pids <= 256:
            raise ValueError("Invalid container resource configuration")
        if not shutil.which("docker"):
            raise ValueError("Docker executor is unavailable")
        self.image, self.memory, self.cpus, self.pids = image, memory, cpus, pids
        self.uid = os.getuid() if os.name == "posix" and os.getuid() != 0 else 10001
        self.gid = os.getgid() if os.name == "posix" and os.getuid() != 0 else 10001

    def base_command(self):
        return ["docker", "run", "--rm", "--pull=never", "--network=none", "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges", "--user", str(self.uid)+":"+str(self.gid), "--memory", self.memory, "--memory-swap", self.memory, "--cpus", self.cpus, "--pids-limit", str(self.pids), "--ulimit", "nofile=64:64", "--ulimit", "fsize=33554432:33554432", "--tmpfs", "/tmp:rw,nosuid,nodev,noexec,size=64m", "--log-driver=none"]

    def readiness(self):
        process = subprocess.run(self.base_command()+[self.image, "--readiness"], capture_output=True, timeout=30, env=self.environment(), check=False)
        if process.returncode or len(process.stdout) > MAX_ENVELOPE_BYTES:
            raise ValueError("Digest-pinned compute-image readiness probe failed")
        result = strict_json(process.stdout)
        if not isinstance(result, dict) or result.get("workerVersion") != WORKER_VERSION:
            raise ValueError("Compute image and control-plane worker versions differ")
        return result

    def execute(self, inputs, outputs, lease, timeout):
        name = "assurance-compute-"+uuid.uuid4().hex
        # Fixed job-owned paths; input is mounted read-only, output is separate.
        command = self.base_command()+["--name", name, "--mount", "type=bind,src="+str(inputs.resolve())+",dst=/inputs,readonly", "--mount", "type=bind,src="+str(outputs.resolve())+",dst=/outputs", self.image, "--compute", "--input-dir", "/inputs", "--output-dir", "/outputs"]
        try:
            self._execute_command(command, inputs, outputs, lease, timeout)
        finally:
            # Killing a docker CLI is insufficient; stop only this generated
            # container, including native-model grandchildren.
            subprocess.run(["docker", "rm", "-f", name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=False, env=self.environment())


def bound_bytes(path, maximum):
    if path.is_symlink() or not path.is_file() or path.stat().st_size > maximum:
        raise ValueError("Compute file violates workspace byte/type bounds")
    raw = path.read_bytes()
    if len(raw) > maximum:
        raise ValueError("Compute file grew beyond bounds")
    return raw


def create_once(path, raw):
    with path.open("xb") as handle:
        handle.write(raw)


def enforce_compute_limits():
    if os.name == "posix":
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (300, 300))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32*1024*1024, 32*1024*1024))
        resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
    # Windows process mode has no OS memory/network sandbox. Native model
    # execution is therefore prohibited there by the outer executor gate.


def compute_job(inputs, outputs):
    envelope = strict_json(bound_bytes(inputs/"envelope.json", MAX_ENVELOPE_BYTES))
    claim = Claim.parse(envelope["claim"], check_expiry=False)
    request = claim.request
    data_path = inputs/"dataset.csv"
    data = bound_bytes(data_path, request["dataset"]["size"])
    if len(data) != request["dataset"]["size"] or sha256(data) != request["inputHashes"]["dataset"]:
        raise ValueError("Dataset byte/hash mismatch")
    rows, _ = read_csv(data_path)
    native = translate_config(request, rows)
    adapter = None
    format_name = FORMAT_ALIASES.get(request["model"].get("format")) if request["executionMode"] == "auditor_model" else None
    if format_name:
        expected = request["inputHashes"]["modelArtifact"]
        if envelope.get("approvedModelSha256") != expected or envelope["execution"].get("networkIsolation") != "docker_network_none":
            raise ValueError("Model is outside the local approved isolated execution boundary")
        spec = native.get("modelSpec")
        if not isinstance(spec, dict):
            raise ValueError("Independent inference requires frozen modelSpec")
        model_path = inputs/("model"+MODEL_SUFFIXES[format_name])
        if sha256(bound_bytes(model_path, MAX_BYTES)) != expected:
            raise ValueError("Model byte/hash mismatch")
        from .optional_adapters import load_adapter
        adapter = load_adapter(model_path, format_name, spec, trusted_model=True)
    elif request["executionMode"] == "auditor_model":
        raise ValueError("Model format is unsupported")
    report = run(data_path, native, adapter=adapter)
    validate_report(report)
    result = evidence_envelope(report, claim, image_digest=envelope["imageDigest"], execution=envelope["execution"])
    payload = json_bytes(result)+b"\n"
    if len(payload) > MAX_RESULT_BYTES:
        raise ValueError("Completed evidence exceeds result byte bounds")
    create_once(outputs/"result.json", payload)
    return result


def compute_main(input_dir, output_dir):
    try:
        enforce_compute_limits()
        inputs, outputs = Path(input_dir).resolve(strict=True), Path(output_dir).resolve(strict=True)
        if inputs == outputs or not inputs.is_dir() or not outputs.is_dir():
            raise ValueError("Input/output directories must be separate")
        compute_job(inputs, outputs)
    except Exception:
        # No raw source rows, secrets, file paths or native stack traces leave
        # the compute process. Operators use dedicated trusted diagnostics.
        return 2
    return 0


class Worker:
    def __init__(self, transport, executor, workspace, *, worker_id, image_digest, formats=(), approved_hashes=(), heartbeat=10, compute_timeout=300, maximum_jobs=100):
        valid_id(worker_id, "workerId")
        if not IMAGE_DIGEST.fullmatch(image_digest):
            raise ValueError("Worker image identity must be sha256:<64 lowercase hex>")
        if not 1 <= heartbeat <= 60 or not 1 <= compute_timeout <= 600 or not 1 <= maximum_jobs <= 10000:
            raise ValueError("Worker resource/time bounds exceeded")
        self.transport, self.executor = transport, executor
        original = Path(workspace).absolute()
        if any(part.is_symlink() for part in (original, *original.parents)):
            raise ValueError("Workspace and its existing ancestors cannot be symlinks")
        self.workspace = original.resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        self.worker_id, self.image_digest = worker_id, image_digest
        if isinstance(executor, DockerExecutor) and executor.image.rsplit("@", 1)[1] != image_digest:
            raise ValueError("Enrolled worker identity differs from compute-image digest")
        self.approved_hashes = frozenset(valid_hash(value, "approved local model") for value in approved_hashes)
        readiness = executor.readiness()
        requested = set(formats)
        if requested - set(MODEL_SUFFIXES):
            raise ValueError("Requested worker format is unsupported")
        if requested and (not executor.permits_models or not self.approved_hashes):
            raise ValueError("Model formats require no-network Docker and locally approved artifact hashes")
        unavailable = [f for f in requested if not readiness.get("modelFormats", {}).get(f, {}).get("runtimePresent")]
        if unavailable:
            raise ValueError("Selected model runtimes are unavailable: "+", ".join(sorted(unavailable)))
        self.formats = ["provided_predictions", *sorted(requested)]
        self.wire_formats = ["provided_predictions", *(WIRE_FORMATS[name] for name in sorted(requested))]
        self.heartbeat, self.compute_timeout, self.maximum_jobs = heartbeat, compute_timeout, maximum_jobs

    def claim(self):
        # No transport retry: an ambiguous claim can have acquired a lease.
        body = self.transport.post({"op": "claim", "workerId": self.worker_id, "imageDigest": self.image_digest, "formats": self.wire_formats})
        if body is None or body == {} or isinstance(body, dict) and body.get("job") is None and "jobId" not in body:
            return None
        return Claim.parse(body.get("job", body) if isinstance(body, dict) else body)

    def at_capacity(self):
        return sum(1 for _ in self.workspace.glob("job-*")) >= self.maximum_jobs

    def execute(self, claim):
        identity = sha256(json_bytes([claim.job_id, claim.attempt_id, claim.fence, claim.nonce, claim.request_sha256]))[:32]
        directory = self.workspace/("job-"+identity)
        if sum(1 for item in self.workspace.glob("job-*")) >= self.maximum_jobs:
            raise ProtocolError("workspace_job_limit")
        directory.mkdir(mode=0o700)
        inputs, outputs = directory/"inputs", directory/"outputs"
        inputs.mkdir(mode=0o700)
        outputs.mkdir(mode=0o700)
        # Docker's fixed UID needs this job-owned output directory. On Windows
        # bind-mount permission semantics are managed by Docker Desktop.
        if isinstance(self.executor, DockerExecutor) and os.name == "posix" and os.getuid() == 0:
            os.chown(outputs, 10001, 10001)
            os.chmod(inputs, 0o755)
            os.chmod(directory, 0o755)
        request = claim.request
        format_name = FORMAT_ALIASES.get(request["model"].get("format")) if request["executionMode"] == "auditor_model" else None
        inference = format_name is not None
        if inference and (format_name not in self.formats or request["inputHashes"]["modelArtifact"] not in self.approved_hashes or not self.executor.permits_models):
            raise ProtocolError("model_not_locally_approved_or_runtime_unavailable")
        if request.get("preprocessing") or request["model"].get("preprocessingArtifactId"):
            if request.get("inputPreparation") != "already_preprocessed":
                raise ProtocolError("executable_preprocessing_unsupported")
        execution = {"kind": "model_inference" if inference else "provided_predictions", "networkIsolation": self.executor.network_isolation, "controller": "client_local_worker" if request["executionMode"] == "client_local" else "external_auditor_worker", "limitations": ["Provided predictions do not establish independent inference or source-label truth."] if not inference else ["This worker evaluates already prepared numeric columns. Feature preparation, dataset independence and artifact safety require separate review."]}
        with LeaseKeeper(self.transport, claim, interval=self.heartbeat) as lease:
            lease.valid()
            data = self.transport.input(claim, "dataset", maximum=request["dataset"]["size"], check_active=lease.valid)
            if len(data) != request["dataset"]["size"] or sha256(data) != request["inputHashes"]["dataset"]:
                raise ProtocolError("dataset_input_pin_mismatch")
            create_once(inputs/"dataset.csv", data)
            if inference:
                model = self.transport.input(claim, "model", maximum=MAX_BYTES, check_active=lease.valid)
                if sha256(model) != request["inputHashes"]["modelArtifact"]:
                    raise ProtocolError("model_input_pin_mismatch")
                declared_size = request["model"].get("size")
                if declared_size is not None and len(model) != declared_size:
                    raise ProtocolError("model_input_size_mismatch")
                create_once(inputs/("model"+MODEL_SUFFIXES[format_name]), model)
            envelope = {"claim": claim.transport_dict(), "imageDigest": self.image_digest, "execution": execution, "approvedModelSha256": request["inputHashes"].get("modelArtifact") if inference else None}
            create_once(inputs/"envelope.json", json_bytes(envelope))
            lease.valid()
            self.executor.execute(inputs, outputs, lease, self.compute_timeout)
            result = bound_bytes(outputs/"result.json", MAX_RESULT_BYTES)
            verify_result_bytes(result, claim, self.image_digest)
            lease.valid()
            body = completion_body(claim, result)
            create_once(directory/"completion.json", body)
            try:
                response = self.transport.post(body, retry=True)
            except ProtocolError as error:
                # Completion may already have committed. Never overwrite it
                # with fail on an ambiguous timeout or retryable server error.
                if error.retryable:
                    raise CompletionUncertain("completion_uncertain") from error
                raise
            return {"jobId": claim.job_id, "attemptId": claim.attempt_id, "resultSha256": sha256(result), "resultFile": str((outputs/"result.json").resolve()), "response": response}

    def once(self):
        if self.at_capacity():
            return {"state": "workspace_capacity_reached", "error": "archive_job_evidence_before_claiming_more_work"}
        claim = self.claim()
        if claim is None:
            return {"state": "idle"}
        try:
            return {"state": "completed", **self.execute(claim)}
        except CompletionUncertain:
            return {"state": "completion_uncertain", "jobId": claim.job_id, "attemptId": claim.attempt_id}
        except (ProtocolError, ValueError, OSError) as error:
            code = error.code if isinstance(error, ProtocolError) else "worker_validation_failed"
            if not isinstance(error, LeaseLost):
                try:
                    self.transport.post({"op": "fail", **claim.pins(), "error": code}, retry=True)
                except ProtocolError:
                    pass
            return {"state": "failed", "jobId": claim.job_id, "attemptId": claim.attempt_id, "error": code}


def verify_result_bytes(result_bytes, claim, image_digest):
    result = strict_json(result_bytes, maximum=MAX_RESULT_BYTES)
    if not isinstance(result, dict) or result.get("schemaVersion") != "1.0":
        raise ValueError("Invalid worker evidence envelope")
    report = result.get("externalReport")
    validate_report(report)
    for field in ("id", "engagementId", "modelId", "datasetId", "seed"):
        if report[field] != claim.request["engineConfig"][field]:
            raise ValueError("Result identity/seed differs from request")
    provenance = result.get("provenance", {})
    if provenance.get("requestSha256") != claim.request_sha256 or provenance.get("imageDigest") != image_digest or provenance.get("executionMode") != claim.request["executionMode"]:
        raise ValueError("Result request/worker identity mismatch")
    if provenance.get("externalReportSha256") != report["reportSha256"]:
        raise ValueError("Embedded report digest mismatch")
    if provenance.get("inputHashes", {}).get("dataset") != claim.request["inputHashes"]["dataset"] or report["provenance"]["inputHashes"]["data"] != claim.request["inputHashes"]["dataset"]:
        raise ValueError("Result dataset hash mismatch")
    inference = claim.request["executionMode"] == "auditor_model"
    if inference and (provenance.get("inputHashes", {}).get("modelArtifact") != claim.request["inputHashes"]["modelArtifact"] or report["provenance"]["inputHashes"].get("model") != claim.request["inputHashes"]["modelArtifact"]):
        raise ValueError("Result model inference hash mismatch")
    from .worker_contract import hosted_results
    if result.get("hostedResults") != hosted_results(report, claim.request):
        raise ValueError("Result projection differs from selected frozen criteria")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="Bounded external pull worker for the assurance platform")
    parser.add_argument("--readiness", action="store_true")
    parser.add_argument("--compute", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--input-dir", help=argparse.SUPPRESS)
    parser.add_argument("--output-dir", help=argparse.SUPPRESS)
    parser.add_argument("--site", default=os.environ.get("ASSURANCE_SITE_ORIGIN"))
    parser.add_argument("--worker-id", default=os.environ.get("ASSURANCE_WORKER_ID"))
    parser.add_argument("--image-digest", default=os.environ.get("ASSURANCE_WORKER_IMAGE_DIGEST"))
    parser.add_argument("--workspace", default="worker-jobs")
    parser.add_argument("--executor", choices=["process", "docker"], default="process")
    parser.add_argument("--compute-image", default=os.environ.get("ASSURANCE_COMPUTE_IMAGE"))
    parser.add_argument("--formats", default="", help="Explicit reviewed native formats, e.g. onnx,xgboost_json; default provided predictions only")
    parser.add_argument("--approved-model-hashes", default=os.environ.get("ASSURANCE_APPROVED_MODEL_HASHES", ""), help="Local reviewed SHA-256 allowlist; never take this from claimed jobs")
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--poll-seconds", type=float, default=5)
    parser.add_argument("--heartbeat-seconds", type=float, default=10)
    parser.add_argument("--compute-timeout", type=float, default=300)
    parser.add_argument("--maximum-jobs", type=int, default=100)
    args = parser.parse_args(argv)
    if args.readiness:
        print(json.dumps(runtime_readiness(), ensure_ascii=False, allow_nan=False))
        return 0
    if args.compute:
        return compute_main(args.input_dir, args.output_dir)
    try:
        if not args.site or not args.worker_id or not args.image_digest or not 1 <= args.poll_seconds <= 60:
            raise ValueError("Site, enrolled worker ID, image digest and bounded poll interval are required")
        token = os.environ.get("ASSURANCE_WORKER_TOKEN")
        if not token:
            raise ValueError("ASSURANCE_WORKER_TOKEN must be provided through the environment/secret manager")
        transport = Transport(args.site, token, os.environ.get("ASSURANCE_SITE_SERVICE_TOKEN"))
        executor = DockerExecutor(args.compute_image) if args.executor == "docker" else ProcessExecutor()
        worker = Worker(transport, executor, args.workspace, worker_id=args.worker_id, image_digest=args.image_digest, formats=filter(None, (f.strip() for f in args.formats.split(","))), approved_hashes=filter(None, (h.strip() for h in args.approved_model_hashes.split(","))), heartbeat=args.heartbeat_seconds, compute_timeout=args.compute_timeout, maximum_jobs=args.maximum_jobs)
        while True:
            try:
                result = worker.once()
            except ProtocolError as error:
                result = {"state": "transport_failed", "error": error.code}
            print(json.dumps(result, ensure_ascii=False, allow_nan=False), flush=True)
            if args.once:
                return 0 if result["state"] in {"completed", "idle"} else 2
            time.sleep(args.poll_seconds)
    except (ValueError, OSError, subprocess.SubprocessError):
        print(json.dumps({"state": "configuration_rejected", "error": "invalid_worker_configuration_or_runtime"}), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
